------------------------------------------------------
-- Autor : Colegio Santa Joaquina de Vedruna
-- Descripción : Script 0 - Formación SQL
-- Responsable : Juan Alejandro Téllez Rubio
-- Alumno 1: Daniel Vazquez Muñoz
-- Alumno 2: Diego López Strickland
-- Alumno 3: Fátima Prieto Alvear
-- Alumno 4: Juan Manuel Hermida Acuña
-- Alumno 5: Alexei Viadero Sanchez
------------------------------------------------------

-- Inserta los estudiantes de la dual
INSERT INTO students VALUES(1,"Daniel","Vazquez", "03/02/1993","667226322",1);
INSERT INTO students VALUES(2,"Agustín","Guerrero", "01/03/2000","734269875",6);
INSERT INTO students VALUES(3,"Alejandro","Pozo", "16/05/2001","734739855",4);
INSERT INTO students VALUES(4,"Alexei","Viadero", "30/01/1983","639767876",1);
INSERT INTO students VALUES(5,"Alma","García", "31/12/1998","634709876",4);
INSERT INTO students VALUES(6,"Álvaro","Rivas", "20/06/2000","604779800",3);
INSERT INTO students VALUES(7,"Álvaro","Rueda", "02/07/2000","630769876",1);
INSERT INTO students VALUES(8,"Andrés","Ruiz", "14/09/1999","694769000",4);
INSERT INTO students VALUES(9,"Daniel","Vazquez", "08/07/1998","704709070",1);
INSERT INTO students VALUES(10,"David Cézar","Fernández", "14/02/1994","622262876",2);
INSERT INTO students VALUES(11,"David Jesús","Rivero", "29/05/2000","620769070",2);
INSERT INTO students VALUES(12,"Diego","López", "05/05/1992","601765872",1);
INSERT INTO students VALUES(13,"Elias","Espinosa", "15/11/1997","678960074",3);
INSERT INTO students VALUES(14,"Fátima","Prieto", "21/05/1996","624260876",1);
INSERT INTO students VALUES(15,"Francisco de Asís","Ferreras", "22/04/1991","700069471",2);
INSERT INTO students VALUES(16,"Francisco Javier","Luna", "01/05/1990","624449875",6);
INSERT INTO students VALUES(17,"Javier","Esmerado", "12/09/1992","666760873",5);
INSERT INTO students VALUES(18,"Javier","Ramos", "01/01/1995","654700074",5);
INSERT INTO students VALUES(19,"Javier","Campos", "14/02/1993","634744076",5);
INSERT INTO students VALUES(20,"Javier","Jiménez", "28/02/1990","600764879",3);
INSERT INTO students VALUES(21,"Juan Jesús","Fernández", "14/01/1989","630766876",6);
INSERT INTO students VALUES(22,"Juan Manuel","Jiménez", "17/07/1992","602761876",6);
INSERT INTO students VALUES(23,"Juan Manuel","Hermida", "15/03/1993","631709077",1);
INSERT INTO students VALUES(24,"Luis Ignacio","Ruíz", "09/09/1984","604760876",4);
INSERT INTO students VALUES(25,"Luis Rafael","Arroyo", "12/03/1993","601739572",2);
INSERT INTO students VALUES(26,"Manuel","Fernández", "23/08/2000","604069076",5);
INSERT INTO students VALUES(27,"Miguel Ángel","Ballano", "27/05/1992","609960871",3);
INSERT INTO students VALUES(28,"Óscar","Castro", "12/02/2000","654969876",3);
INSERT INTO students VALUES(29,"Rafael","Ortega", "11/09/1991","650740871",2);
INSERT INTO students VALUES(30,"Raquel","Díaz", "10/12/1983","600062876",5);
INSERT INTO students VALUES(31,"Samuel","Castro", "11/02/2000","610160836",4);
INSERT INTO students VALUES(32,"Sebastián Alejandro","Cornero", "10/09/1994","717709821",4);
INSERT INTO students VALUES(33,"Tomás","Mota", "14/01/1997","634769876",6);