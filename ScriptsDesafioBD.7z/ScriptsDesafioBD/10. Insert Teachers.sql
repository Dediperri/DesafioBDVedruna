------------------------------------------------------
-- Autor : Colegio Santa Joaquina de Vedruna
-- Descripción : Script 0 - Formación SQL
-- Responsable : Juan Alejandro Téllez Rubio
-- Alumno 1: Daniel Vazquez Muñoz
-- Alumno 2: Diego López Strickland
-- Alumno 3: Fátima Prieto Alvear
-- Alumno 4: Juan Manuel Hermida Acuña
-- Alumno 5: Alexei Viadero Sanchez
------------------------------------------------------

-- Inserta los profesores o formadores
INSERT INTO teachers VALUES (1,"Juan Alejandro", "Tellez");
INSERT INTO teachers VALUES (2,"Jesus Alberto", "Castaño");
INSERT INTO teachers VALUES (3,"Jose María", "Bernal");
INSERT INTO teachers VALUES (4,"Juan Manuel", "Hermidia");
INSERT INTO teachers VALUES (5,"Darío", "García");
INSERT INTO teachers VALUES (6,"Fátima", "Prieto");