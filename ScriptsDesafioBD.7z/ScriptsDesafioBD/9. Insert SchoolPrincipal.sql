------------------------------------------------------
-- Autor : Colegio Santa Joaquina de Vedruna
-- Descripción : Script 0 - Formación SQL
-- Responsable : Juan Alejandro Téllez Rubio
-- Alumno 1: Daniel Vazquez Muñoz
-- Alumno 2: Diego López Strickland
-- Alumno 3: Fátima Prieto Alvear
-- Alumno 4: Juan Manuel Hermida Acuña
-- Alumno 5: Alexei Viadero Sanchez
------------------------------------------------------

-- Inserta los directores
INSERT INTO schoolprincipal VALUES (1,"Kiko", "Matamoros");
INSERT INTO schoolprincipal VALUES (2,"David", "Pozo");
INSERT INTO schoolprincipal VALUES (3,"Javier", "Ruiz");
INSERT INTO schoolprincipal VALUES (4,"María", "Pérez");
INSERT INTO schoolprincipal VALUES (5,"Lucía", "Vázquez");
INSERT INTO schoolprincipal VALUES (6,"Jorge Juan", "Muñoz");