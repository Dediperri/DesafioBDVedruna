------------------------------------------------------
-- Autor : Colegio Santa Joaquina de Vedruna
-- Descripción : Script 0 - Formación SQL
-- Responsable : Juan Alejandro Téllez Rubio
-- Alumno 1: Daniel Vazquez Muñoz
-- Alumno 2: Diego López Strickland
-- Alumno 3: Fátima Prieto Alvear
-- Alumno 4: Juan Manuel Hermida Acuña
-- Alumno 5: Alexei Viadero Sanchez
------------------------------------------------------

-- Inserta los institutos
INSERT INTO highschool VALUES (1,"Santa Joaquina de Vedruna", "Sevilla",1);
INSERT INTO highschool VALUES (2, "I.E.S. Alixar", "Sevilla", 2);
INSERT INTO highschool VALUES (3, "I.E.S. Hermanos Machado", "Sevilla", 3);
INSERT INTO highschool VALUES (4, "I.E.S. Sotero Hernández","Huelva", 4);
INSERT INTO highschool VALUES (5, "Salesianas de María Auxiliadora","Granada", 5);
INSERT INTO highschool VALUES (6, "Salesianas de San Ignacio","Cádiz", 6);