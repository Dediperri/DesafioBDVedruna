------------------------------------------------------
-- Autor : Colegio Santa Joaquina de Vedruna
-- Descripción : Script 0 - Formación SQL
-- Responsable : Juan Alejandro Téllez Rubio
-- Alumno 1: Daniel Vazquez Muñoz
-- Alumno 2: Diego López Strickland
-- Alumno 3: Fátima Prieto Alvear
-- Alumno 4: Juan Manuel Hermida Acuña
-- Alumno 5: Alexei Viadero Sanchez
------------------------------------------------------

-- Inserta las asignaturas
INSERT INTO subjects VALUES (1, "Entorno de Desarrollo", 1);
INSERT INTO subjects VALUES (2, "Base de Datos", 1);
INSERT INTO subjects VALUES (3, "Lenguaje de Marcas-HTML", 4);
INSERT INTO subjects VALUES (4, "Lenguaje de Marcas-CSS", 6);
INSERT INTO subjects VALUES (5, "Lenguaje de Marcas-JavaScript", 3);
INSERT INTO subjects VALUES (6, "Programación", 1);
INSERT INTO subjects (idSubjects, name) VALUES (7, "Formación y Orientación Laboral");